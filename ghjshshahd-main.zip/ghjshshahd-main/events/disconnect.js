module.exports = client => {
  console.log(`Offline! ${new Date()}`);
};
